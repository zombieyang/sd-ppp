global.sdpppX = {
  "tenantid": "65b95867-1c57-42ed-baa5-849a89790b51",
  "settings.imaging.defaultImagesSizeLimit": 2048
}
