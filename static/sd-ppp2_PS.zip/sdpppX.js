global.sdpppX = {
  "settings.imaging.defaultImagesSizeLimit": 2048
}
