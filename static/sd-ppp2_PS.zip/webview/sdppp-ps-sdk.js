const p=globalThis.sdpppSDK;export{p as sdpppSDK};
